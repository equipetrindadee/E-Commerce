import React from "react"
import '../Dashboard/dashboard.css'
export const Dashboard = () => {
    return (
        <body>
    <div>
        {/* NavBar  */}
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <img src="./img/logo.png" alt="" />
            
            <i class="bi bi-person-circle perfil"></i>
       
        </nav>
        {/* Corpo  */}

        <div class="content">
            <div class="info-dashboard"> 
                <div class="card usuarios">
                    <div class="card-body usuarios">
                        <i class="bi bi-people-fill"></i>
                        <h6>397</h6>
                        <p class="card-text">Usuários</p>
                    </div>
                </div>

                <div class="card entregas">
                    <div class="card-body entregas" id="card_user">
                        <i class="bi bi-floppy"></i>
                        <h6>43</h6>
                        <p class="card-text">Entregas</p>
                    </div>
                </div>
                <div class="card completas">
                    <div class="card-body completas" id="card_user">
                        <i class="bi bi-check-circle"></i>
                        <h6>12</h6>
                        <p class="card-text">Completas</p>
                    </div>
                </div>
                <div class="card alertas">
                    <div class="card-body alertas" id="card_user">
                        <i class="bi bi-exclamation-triangle-fill"></i>
                        <h6>1</h6>
                        <p class="card-text">Alerta</p>
                    </div>
                </div>
            </div>
             {/* footer  */}
            <div class="footer-dashboard">
                <img class="moca-lapis" src="./img/moca.png"  alt="icone-perfil" />

       { /* parte menu */ }

                <div class="menu">

                    <button type="button" class="btn  menu-button"> 
                        <a class="nav-link active" aria-current="page" href="/dashboard"><i class="bi bi-columns-gap"></i></a>
                            
                    </button>
                    <button type="button" class="btn menu-button">
                            <a class="nav-link" href="/listar"><i class="bi bi-exclamation-lg"></i></a>
                            
                        </button>
                        <button type="button" class="btn  menu-button">
                            <a class="nav-link" href="/formulario"><i class="bi bi-eye"></i></a>
                            
                        </button>
                        <button type="button" class="btn  menu-button">
                            <a class="nav-link" href="/visualizar"><i class="bi bi-list"></i></a>
                         
                        </button>

                        <button type="button" class="btn  menu-button">
                            <a class="nav-link" href="/alerta"><i class="bi bi-pen-fill"></i></a>
                           
                        </button>
                        <button type="button" class="btn  close">
                            <a class="nav-link" href="#"><i class="bi bi-x-circle"></i></a>
                            
                        </button>
                </div>
                {/* fim menu */ }
                </div> 
                { /* fim do footer */  }
        </div>
    </div>
    
</body>
    )
}

export default Dashboard