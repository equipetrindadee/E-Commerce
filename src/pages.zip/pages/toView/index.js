import React, { useState, useEffect } from 'react';
import api from "../../config/configApi.js"
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'
import '../toView/toView.css'

export const View = () => {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState(null);
    const [showPopover, setShowPopover] = useState(null)

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await api.get('/users');
                setUsers(Array.isArray(response.data.users) ? response.data.users : []);
            } catch (error) {
                console.error('Erro ao obter os usuários:', error);
                setError(error.message);
            }
        };

        fetchData();
    }, []);

    return (
        <div>
            <header>
                <nav className="navbar navbar-view fixed-top">
                    <div className="container-fluid">

                        <a className="navbar-brand " href="#">Alpha</a>
                        <div className="d-lg-flex align-items-center">
                            {/* Botão de dropdown */}
                            <div className="dropdown d-none d-lg-block">
                                <button
                                    className="btn dropdown-toggle"
                                    type="button"
                                    id="dropdownMenuButton"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                >
                                    <i className="bi bi-person-circle"></i>
                                </button>
                                <ul
                                    className="dropdown-menu dropdown-menu-end"
                                    aria-labelledby="dropdownMenuButton"
                                >
                                    <li>
                                        <a className="dropdown-item" href="#">
                                            Perfil
                                        </a>
                                    </li>
                                    <li>
                                        <a className="dropdown-item" href="#">
                                            Logout
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            {/* Botão de toggle para o offcanvas */}
                            <button className="navbar-toggler d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                                <i className="bi bi-person-circle"></i>
                            </button>
                        </div>

                        {/* Offcanvas */}
                        <div className="offcanvas offcanvas-end" tabIndex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                            <div className="offcanvas-header">
                                <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>
                            <div className="offcanvas-body">
                                <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                                    <li className="nav-item">
                                        <a className="nav-link active" aria-current="page" href="#">
                                            Deshboard
                                        </a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">
                                            Alerta
                                        </a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">
                                            Visualizar
                                        </a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">
                                            Listar
                                        </a>
                                    </li>
                                    <li className="nav-item">
                                        <a className="nav-link" href="#">
                                            Cadastrar
                                        </a>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Perfil
                                        </a>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#">Logout</a></li>
                                            <li><a class="dropdown-item" href="#">Meu perfil</a></li>

                                        </ul>
                                    </li>

                                </ul>
                            </div>
                        </div>
                    </div>
                </nav>
            </header>
            <body>
                <div className="content">

                    <div className="content-layout">
                        <h2>Users</h2>
                        <img src="../img/img_view.svg" alt="" />

                        <nav aria-label="Page navigation example">
                            <ul className="pagination">
                                <li className="page-item" ><a className="page-link" href="#"><i className="bi bi-arrow-left"></i></a></li>
                                <li className="page-item"><a className="page-link" href="#">1</a></li>
                                <li className="page-item"><a className="page-link" href="#">2</a></li>
                                <li className="page-item"><a className="page-link" href="#">3</a></li>
                                <li className="page-item"><a className="page-link" href="#"><i className="bi bi-arrow-right"></i></a></li>
                            </ul>
                        </nav>


                    </div>
                    <div className="content-card">
                        {users.map(user => (
                            <div key={user.id} className="card-info">
                                {/* INFORMAÇÕES DO INICIO */}
                                <div className="info-header">

                                    <div className='users'>
                                        <i className="bi bi-person-circle"></i>
                                        <p>{user.id}</p>
                                    </div>
                                    <button type="button" className="btn" data-bs-toggle="modal" data-bs-target={`#staticBackdrop-${user.id}`}>
                                        <img src="../img/plus.svg" alt="" />
                                    </button>

                                    {/* MODAL */}

                                    <div className="modal fade" id={`staticBackdrop-${user.id}`} data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby={`staticBackdropLabel-${user.id}`} aria-hidden="true">
                                        <div className="modal-dialog">
                                            <div className="modal-content">
                                                <div className="modal-header">
                                                    <i className="bi bi-person-circle"></i>
                                                    {/* <button type="button"data-bs-dismiss="modal" aria-label="Close"><i className="bi bi-x"></i></button> */}
                                                </div>
                                                <div className="modal-body">
                                                    <ul >
                                                        <li>
                                                            <h3>id:</h3>
                                                            <p>{user.id}</p>
                                                        </li>
                                                        <li>
                                                            <h3>Nome:</h3>
                                                            <p>{user.name}</p>
                                                        </li>
                                                        <li>
                                                            <h3>CPF:</h3>
                                                            <p>{user.cpf}</p>
                                                        </li>
                                                        <li>
                                                            <h3>Email:</h3>
                                                            <p>{user.email}</p>
                                                        </li>
                                                        <li>
                                                            <h3>Estado:</h3>
                                                            <p>{user.estado}</p>
                                                        </li>
                                                        <li>
                                                            <h3>Cidade:</h3>
                                                            <p>{user.cidade}</p>
                                                        </li>
                                                        <li>
                                                            <h3>Rua:</h3>
                                                            <p>{user.rua}</p>
                                                        </li>
                                                        <li>
                                                            <h3>CEP:</h3>
                                                            <p>{user.cep}</p>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div className="modal-footer">
                                                    <button type="button" className="btn btn-light" data-bs-dismiss="modal">Close</button>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="info-body">
                                    <ul >
                                        <li>
                                            <h3>Nome:</h3>
                                            <p>{user.name}</p>
                                        </li>
                                        <li>
                                            <h3>CPF:</h3>
                                            <p>{user.email}</p>
                                        </li>
                                    </ul>

                                </div>
                            </div>
                        ))}
                    </div>
                    <nav aria-label="Page navigation example">
                        <ul className=" pagination pagination-mobile">
                            <li className="page-item" ><a className="page-link" href="#"><i className="bi bi-arrow-left"></i></a></li>
                            <li className="page-item"><a className="page-link" href="#">1</a></li>
                            <li className="page-item"><a className="page-link" href="#">2</a></li>
                            <li className="page-item"><a className="page-link" href="#">3</a></li>
                            <li className="page-item"><a className="page-link" href="#"><i className="bi bi-arrow-right"></i></a></li>
                        </ul>
                    </nav>
                    <footer className="fixed-bottom">

                        <nav className="navbar navbar-expand-md bottom-navbar">
                            <button className="navbar-toggler close-btn" type="button" data-toggle="collapse" data-target="#bottomNavbar">
                                <span>&times;</span>
                            </button>
                            <div className="collapse navbar-collapse" id="bottomNavbar">
                                <ul className="navbar-nav">
                                    <li className="nav-item">
                                        <div className="circle-img">
                                            <a href="../dashboard/index.js"><img src="img/img_iconDeshboard.svg" alt="Imagem" /></a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <div className="circle-img">
                                            <a href="../dashboard/index.js"><img src="img/img_iconAlert.svg" alt="Imagem" /></a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <div className="circle-img">
                                            <a href="../dashboard/index.js"><img src="img/img_iconView.svg" alt="Imagem" /></a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <div className="circle-img">
                                            <a href="../dashboard/index.js"><img src="img/img_iconList.svg" alt="Imagem" /></a>
                                        </div>
                                    </li>
                                    <li className="nav-item">
                                        <div className="circle-img">
                                            <a href="../dashboard/index.js"><img src="img/img_iconEdit.svg" alt="Imagem" /></a>
                                        </div>
                                    </li>

                                    <a className="button-close"><p>X</p></a>

                                </ul>
                            </div>
                        </nav>
                    </footer>
                </div>
            </body>
        </div>
    )
}

export default View
