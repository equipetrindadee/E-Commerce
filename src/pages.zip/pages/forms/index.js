import "../forms/forms.css"
import React, { useState } from 'react';
import api from "../../config/configApi.js"
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

export const Forms = () => {
  const navigate = useNavigate()

  const [user, setUser] = useState({
      name: '',
      email: '',
      password: '',
      cpf: '',
      estado: '',
      cidade: '',
      cep: '',
      rua: ''
  });

  const [status, setStats] = useState({
      type: '',
      mensagem: ''
  });

  const usuariosUpdate = (e) => {
      const { name, value } = e.target;
      let newValue = value;

      if (name === 'cpf') {
          newValue = value.replace(/\D/g, '');
          newValue = newValue.slice(0, 11);
      }

      if (name === 'email') {
          newValue = value.replace(/[^a-zA-Z0-9@.]/g, '');
      }

      if (name === 'password') {
          newValue = newValue.slice(0, 16);
      }


      setUser(prevState => ({
          ...prevState,
          [name]: newValue
      }));
  };

  const handleCEPChange = async (e) => {
      const cep = e.target.value.replace(/\D/g, '');

      setUser(prevState => ({
          ...prevState,
          cep: cep
      }));

      if (cep.length === 8) {
          try {
              const response = await axios.get(`https://viacep.com.br/ws/${cep}/json/`);
              const { uf, localidade, logradouro } = response.data;
              setUser(prevState => ({
                  ...prevState,
                  estado: uf,
                  cidade: localidade,
                  rua: logradouro
              }));
          } catch (error) {
              console.error('Erro ao buscar informações do CEP:', error);
          }
      }
  };

  const postSubmit = async e => {
      const headers = {
          'Content-Type': 'application/json'
      };

      if (Object.values(user).some(value => value === '')) {
          setStats({
              type: 'error',
              mensagem: "Por favor, preencha todos os campos."
          });
          return;
      }

      try {
          await api.post('/user', user, { headers })
              .then((response) => {
                  setStats({
                      type: 'success',
                      mensagem: response.data.mensagem
                  });
                  navigate("/");
              });
      } catch (error) {
          if (error.response) {
              setStats({
                  type: 'error',
                  mensagem: error.response.data.mensagem
              });
          } else {
              setStats({
                  type: 'error',
                  mensagem: "Servidor está em manutenção, tente novamente mais tarde"
              });
          }
      }
  };
  return (
    <div>
      <header>
        <nav className="navbar navbar-forms fixed-top">
          <div className="container-fluid">

            <a className="navbar-brand navbar-brand-forms" href="#">Alpha</a>


           
            <button className="navbar-toggler d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
          </div>

          {/* Offcanvas */}
          <div className="offcanvas offcanvas-end" tabIndex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div className="offcanvas-header">
              <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div className="offcanvas-body">
              <ul className="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li className="nav-item">
                  <a className="nav-link active" aria-current="page" href="#">
                    Deshboard
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Alerta
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Visualizar
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Listar
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">
                    Cadastrar
                  </a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Perfil
                  </a>
                  <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Logout</a></li>
                    <li><a class="dropdown-item" href="#">Meu perfil</a></li>

                  </ul>
                </li>

              </ul>
            </div>
          </div>

        </nav>
      </header>

      <body>

{/*       
        <div className="content-forms">
          <div className="info-header-forms">
            <h1>Cadastrar</h1>
            <button type="button" class="btn btn-cadastrar ">CADASTRAR</button>
          </div>


        </div> */}

<div className="content-layout-forms">
                        <h2>  Cadastrar</h2>
                        <img src="../img/img_centro.svg" alt="" />
                        {status.type === 'error' ? <p className='mensagemError'>{status.mensagem}</p> : ""}
                        <button type="button" class="btn btn-cadastrar " onClick={postSubmit}>CADASTRAR</button>

                    </div>


      

        <div class="container">
          <form>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="nome">Nome</label>
                  <input type="text" className="form-control" placeholder="Nome Completo" name="name" value={user.name} onChange={usuariosUpdate} required />   
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="text" className="form-control" placeholder="Meu Email" name="email" value={user.email} onChange={usuariosUpdate} required />
                </div>
                <div class="form-group">
                  <label for="senha">Senha</label>
                  <input type="password" className="form-control" placeholder="Senha" name="password" value={user.password} onChange={usuariosUpdate} required />
                </div>
                <div class="form-group">
                  <label for="cpf">CPF</label>
                  <input type="text" className="form-control" placeholder="Meu CPF" name="cpf" value={user.cpf} onChange={usuariosUpdate} required />
                </div>
              </div>
              <div class="col-md-6">
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="cep">CEP</label>
                      <input type="text" className="form-control" placeholder="CEP" name="cep" value={user.cep} onChange={handleCEPChange} required />
                    </div>
                  </div>
                </div>
                <div class="row city">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label for="cidade">Cidade</label>
                      <input type="text" className="form-control" placeholder="cidade" name="cidade" value={user.cidade} onChange={usuariosUpdate} required />
                    </div>
                  </div>
                  <div class="col-md-6 state">
                    <div class="form-group">
                      <label for="estado">Estado</label>
                      <input type="text" className="form-control" placeholder="estado" name="estado" value={user.estado} onChange={usuariosUpdate} required />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="endereco">Endereço</label>
                      <input type="text" className="form-control" placeholder="RUA" name="rua" value={user.rua} onChange={usuariosUpdate} required />
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label for="complemento">Complemento</label>
                      {/* <input type="text" className="form-control" placeholder="Complemento" name="complemento" value={user.complemento} onChange={usuariosUpdate} required /> */}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
          <div className="btn-cadastrar-mobile-footer ">
          <button type="button" class="btn btn-cadastrar-m " onClick={postSubmit}>CADASTRAR</button>
        </div>
        </div>
        

        {/* <footer className="fixed-bottom">

          <nav className="navbar navbar-expand-md bottom-navbar">
            <button className="navbar-toggler close-btn" type="button" data-toggle="collapse" data-target="#bottomNavbar">
              <span>&times;</span>
            </button>
            <div className="collapse navbar-collapse" id="bottomNavbar">
              <ul className="navbar-nav">
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconDeshboard.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconAlert.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconView.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconList.svg" alt="Imagem" /></a>
                  </div>
                </li>
                <li className="nav-item">
                  <div className="circle-img">
                    <a href="../dashboard/index.js"><img src="img/img_iconEdit.svg" alt="Imagem" /></a>
                  </div>
                </li>

                <a className="button-close"><p>X</p></a>

              </ul>
            </div>
          </nav>
        </footer> */}

      </body>
    </div>


  )
}

export default Forms;
