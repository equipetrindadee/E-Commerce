import React from "react"

export const ChangePass = () => {
    return (
        <div>
             <div className="card-changePass">
            
                <img src="/img/logo.png" alt="" />
            
                
                <form>
                    <div className="info-Login">
                        <div className="row mb-3" >
                            <div className="col-sm-10">
                                <h3>Informe seu email</h3>
                                <input type="email" name="email" placeholder="Digite o seu email"/>
                            </div>
                        </div>
                    </div>
                    <div className="infos">
                        
                        <button type="submit" className="btn"><a href="/dashboard">Entrar</a></button>  
                    </div>
                    
                </form>
            </div>
        </div>
    )
}

export default ChangePass